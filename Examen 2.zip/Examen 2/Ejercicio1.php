<?php 
$number = 7
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <h1>Tabla de multiplicar del <?= $number?></h1>
    <table>
        <?
        //Declaracion del bucle
        for($i =1;$i<11;$i++){
            echo '<tr>';
            //Mostar el numero de la tabla que va a multiplicar
            echo '<td>';
            echo $number;
            echo '</td>';

            //Mostar el *
            echo '<td>';
            echo '*';
            echo '</td>';

            //Mostar el numero del bucle
            echo '<td>';
            echo $i;
            echo '</td>';

            //Mostral el igual
            echo '<td>';
            echo '=';
            echo '</td>';

            //Mostar la multiplicacion

            echo '<td>';
            echo $number * $i;
            echo '</td>';

            echo '</tr>';


        }
        ?>
    </table>
</body>
</html>